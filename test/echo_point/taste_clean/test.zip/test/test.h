/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_test__
#define __USER_CODE_H_test__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void test_startup();

void test_PI_run();

void test_PI_point32fromRos(const asn1SccGeometry_msgs_Point32 *);

extern void test_RI_pointToRos(const asn1SccGeometry_msgs_Point *);

#ifdef __cplusplus
}
#endif


#endif
